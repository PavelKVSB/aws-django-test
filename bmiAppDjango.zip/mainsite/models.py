from django.db import models

# Create your models here.

class Sportovci(models.Model):
    jmeno = models.CharField(max_length=30, null=True)
    prijmeni = models.CharField(max_length=30, null=True)
    email = models.CharField(max_length=50, null=True)
    zamestnani = models.CharField(max_length=100, null=True)
    vaha = models.FloatField()
    vyska = models.FloatField()
    vek = models.FloatField()
    bmi = models.FloatField()
    dateCreated = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self): #tohle je jen podstatne pro zobrazeni v panelu admina
        return self.prijmeni 
    
    # Jedna moznost je pridani virtualniho pole
    @property
    def bmiCalc(self):
        bmi = self.vaha / (self.vyska**2)
        return bmi

    

