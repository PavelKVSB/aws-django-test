from django.contrib import admin
from .models import Sportovci

# Register your models here.


# Register your models here.
admin.site.register(Sportovci)
