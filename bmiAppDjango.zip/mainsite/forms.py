from django.forms import ModelForm
from django import forms
from .models import Sportovci

class SportovciForm(ModelForm):

    jmeno = forms.CharField(required=True, label = "Zadejte jméno sportovce")
    prijmeni = forms.CharField(required=True, label = "Zadejte příjmení sportovce")
    email = forms.CharField(required=True, label = "Zadejte email sportovce")
    zamestnani = forms.CharField(required=True, label = "Zadejte pracovní pozici sportovce")
    vaha = forms.FloatField(required=True, label = "Zadejte váhu sportovce")
    vyska = forms.FloatField(required=True, label = "Zadejte výšku sportovce")
    vek = forms.FloatField(required=True, label = "Zadejte věk sportovce")

    class Meta:
        model = Sportovci
        fields = ['jmeno','prijmeni','email','zamestnani','vaha','vyska','vek']    #'__all__' takto dotaneme všechna pole


