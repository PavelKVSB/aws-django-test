from django.shortcuts import render
from .models import Sportovci
from .forms import SportovciForm

# Create your views here.

def home(request):
    return render(request, 'mainsite/index.html')

def add(request):

    add_data = "Přidej data"

    form = SportovciForm

    # https://github.com/blasferna/django-calculation

    if request.method == 'POST':
        form = SportovciForm(request.POST)

        if form.is_valid():
            instance = form.save(commit=False)
            instance.bmi = calc_bmi(instance.vaha, instance.vyska)
            instance.save()
            form = SportovciForm

    return render(request, 'mainsite/add.html', {'data_add':form})

    
def calc_bmi(vaha,vyska):
    bmi_value = vaha / (vyska**2)
    return bmi_value


def view(request):

    data_input = [
        {
        "Jmeno" : "Pavel",
        "Prijmeni" : "Kukuliac",
        "Vek" : 37,
        "Email" : "kuk064@vsb.cz",
        "Zamestani" : "Odborny assitent",
        "Váha" : 95,
        "Výška" : 1.85
        },
                {
        "Jmeno" : "Tomas",
        "Prijmeni" : "Maly",
        "Vek" : "25",
        "Email" : "maly007@vsb.cz",
        "Zamestani" : "Technicky pracovnik",
        "Váha" : 80,
        "Výška" : 1.95
        }
    ]

    data_db = Sportovci.objects.all()

    return render(request, 'mainsite/view.html', {'data_view':data_input, 'db_view':data_db})